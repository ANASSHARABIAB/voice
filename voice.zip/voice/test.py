import requests
import os

# --- 1. SET YOUR CREDENTIALS AND FILE PATH ---
# Replace these with your actual values from the Azure portal
# Azure OpenAI Whisper endpoint details (set your values here or via env vars)
AZURE_OPENAI_ENDPOINT = 'https://anas-mdxjmq2n-eastus2.cognitiveservices.azure.com/openai/deployments/whisper/audio/translations?api-version=2024-06-01'
AZURE_OPENAI_API_KEY = 'BlUF94rjypTYkZXdnEwYEP1lVH3h9cMQDX0QeWJiDhOgbmdkWNKDJQQJ99BHACHYHv6XJ3w3AAAAACOGZhI0'
AZURE_OPENAI_DEPLOYMENT = 'whisper'

# Replace with the path to your .wav file
AUDIO_FILE_PATH = r"C:\Users\user\Desktop\voice\d7d384be-c974-4bae-a7f6-99673486041c.wav"

# --- 2. CONSTRUCT THE FULL API URL ---
# The API version can be adjusted as new versions are released
API_VERSION = "2024-02-01"
full_url = f"{AZURE_OPENAI_ENDPOINT.rstrip('/')}/openai/deployments/{AZURE_OPENAI_DEPLOYMENT}/audio/transcriptions?api-version={API_VERSION}"
full_url = AZURE_OPENAI_ENDPOINT
# --- 3. PREPARE AND SEND THE REQUEST ---
headers = {
    "api-key": AZURE_OPENAI_API_KEY,
    "Ocp-Apim-Subscription-Key": AZURE_OPENAI_API_KEY
}

# Check if the audio file exists
if not os.path.exists(AUDIO_FILE_PATH):
    print(f"Error: Audio file not found at '{AUDIO_FILE_PATH}'")
else:
    try:
        # Open the audio file in binary mode
        with open(AUDIO_FILE_PATH, "rb") as audio_file:
            files = {
                'file': (os.path.basename(AUDIO_FILE_PATH), audio_file, 'audio/wav')
            }
            
            print("Sending request to Azure OpenAI... 🚀")
            
            # Send the POST request
            response = requests.post(full_url, headers=headers, files=files)
            
            # --- 4. HANDLE THE RESPONSE ---
            if response.status_code == 200:
                transcription = response.json()
                print("\n✅ Transcription Successful!")
                print("-----------------------------")
                print(transcription['text'])
                print("-----------------------------")
            else:
                print(f"\n❌ Error {response.status_code}:")
                print(response.text)

    except Exception as e:
        print(f"An error occurred: {e}")