import os
from fastapi import FastAPI, File, UploadFile, HTTPException
import requests
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

# # Azure OpenAI Whisper endpoint details (set your values here or via env vars)
# AZURE_OPENAI_ENDPOINT = os.environ.get("AZURE_OPENAI_ENDPOINT", "https://YOUR-RESOURCE-NAME.openai.azure.com/")
# AZURE_OPENAI_API_KEY = os.environ.get("AZURE_OPENAI_API_KEY", "YOUR_API_KEY")
# AZURE_OPENAI_DEPLOYMENT = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "whisper-deployment-name")  # Your deployment name

# Azure OpenAI Whisper endpoint details (set your values here or via env vars)
AZURE_OPENAI_ENDPOINT = 'https://anas-mdxjmq2n-eastus2.cognitiveservices.azure.com/openai/deployments/whisper/audio/translations?api-version=2024-06-01'
AZURE_OPENAI_API_KEY = 'BlUF94rjypTYkZXdnEwYEP1lVH3h9cMQDX0QeWJiDhOgbmdkWNKDJQQJ99BHACHYHv6XJ3w3AAAAACOGZhI0'
AZURE_OPENAI_DEPLOYMENT = 'whisper'


# Whisper API path for Azure OpenAI
FULL_URL = AZURE_OPENAI_ENDPOINT

app = FastAPI()

# Allow CORS for local development (optional, safe for local use)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve static files (frontend UI)
app.mount("/static", StaticFiles(directory="static"), name="static")

# Route '/' to the UI
@app.get("/")
def read_index():
    return FileResponse("static/index.html")

@app.post("/transcribe")
async def transcribe_audio(file: UploadFile = File(...)):
    if not file.filename.endswith(".wav"):
        raise HTTPException(status_code=400, detail="Only .wav files are supported.")
    
    # Prepare headers for Azure OpenAI
    headers = {
        "api-key": AZURE_OPENAI_API_KEY
    }
    # Prepare multipart/form-data for Whisper
    files = {
        "file": (file.filename, await file.read(), "audio/wav"),
        "response_format": (None, "json"),
        "language": (None, "en")  # Optional: specify language
    }

    try:
        response = requests.post(FULL_URL, headers=headers, files=files)
        response.raise_for_status()
    except requests.HTTPError as e:
        return JSONResponse(status_code=500, content={"error": str(e), "details": response.text})

    data = response.json()
    transcript = data.get("text", "")
    return {"transcript": transcript}

# Alias for frontend compatibility: '/process' -> '/transcribe'
@app.post("/process")
async def process_audio(file: UploadFile = File(...)):
    return await transcribe_audio(file)
