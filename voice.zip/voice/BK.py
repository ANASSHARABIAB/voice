import os
from fastapi import FastAPI, File, UploadFile, HTTPException
import requests
from fastapi.responses import JSONResponse

# Azure OpenAI Whisper endpoint details (set your values here or via env vars)
AZURE_OPENAI_ENDPOINT = os.environ.get("AZURE_OPENAI_ENDPOINT", "https://YOUR-RESOURCE-NAME.openai.azure.com/")
AZURE_OPENAI_API_KEY = os.environ.get("AZURE_OPENAI_API_KEY", "YOUR_API_KEY")
AZURE_OPENAI_DEPLOYMENT = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "whisper-deployment-name")  # Your deployment name

# Whisper API path for Azure OpenAI
FULL_URL = AZURE_OPENAI_ENDPOINT

app = FastAPI()

@app.post("/transcribe")
async def transcribe_audio(file: UploadFile = File(...)):
    if not file.filename.endswith(".wav"):
        raise HTTPException(status_code=400, detail="Only .wav files are supported.")
    
    # Prepare headers for Azure OpenAI
    headers = {
        "api-key": AZURE_OPENAI_API_KEY
    }
    # Prepare multipart/form-data for Whisper
    files = {
        "file": (file.filename, await file.read(), "audio/wav"),
        "response_format": (None, "json"),
        "language": (None, "en")  # Optional: specify language
    }

    try:
        response = requests.post(FULL_URL, headers=headers, files=files)
        response.raise_for_status()
    except requests.HTTPError as e:
        return JSONResponse(status_code=500, content={"error": str(e), "details": response.text})

    data = response.json()
    transcript = data.get("text", "")
    return {"transcript": transcript}
